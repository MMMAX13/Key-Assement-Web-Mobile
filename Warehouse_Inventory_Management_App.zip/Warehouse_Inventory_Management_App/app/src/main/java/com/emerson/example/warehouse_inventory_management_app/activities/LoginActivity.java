package com.emerson.example.warehouse_inventory_management_app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.emerson.example.warehouse_inventory_management_app.R;
import com.emerson.example.warehouse_inventory_management_app.api.ApiClient;
import com.emerson.example.warehouse_inventory_management_app.models.LoginResponse;
import com.emerson.example.warehouse_inventory_management_app.models.User;
import com.emerson.example.warehouse_inventory_management_app.utils.SharedPrefManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilEmail, tilPassword;
    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private ProgressBar progressBar;
    private TextView tvServerConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (SharedPrefManager.getInstance(this).isLoggedIn()) {
            startDashboard();
            return;
        }

        setContentView(R.layout.activity_login);

        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);
        tvServerConfig = findViewById(R.id.tvServerConfig);

        btnLogin.setOnClickListener(v -> attemptLogin());
        tvServerConfig.setOnClickListener(v -> showServerConfigDialog());
    }

    private void attemptLogin() {
        tilEmail.setError(null);
        tilPassword.setError(null);

        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(password)) {
            tilPassword.setError(getString(R.string.err_password_empty));
            focusView = etPassword;
            cancel = true;
        }

        if (TextUtils.isEmpty(email)) {
            tilEmail.setError(getString(R.string.err_email_empty));
            focusView = etEmail;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
            return;
        }

        setLoading(true);

        ApiClient.getApiService(this).login(email, password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();
                    if (loginResponse.isSuccess()) {
                        User user = loginResponse.getUser();
                        if (user != null) {
                            SharedPrefManager.getInstance(LoginActivity.this).saveUser(user);
                            Toast.makeText(LoginActivity.this, "Welcome, " + user.getFullName(), Toast.LENGTH_SHORT).show();
                            startDashboard();
                        } else {
                            showError("User session data missing from server response.");
                        }
                    } else {
                        showError(loginResponse.getMessage());
                    }
                } else if (response.code() == 401) {
                    showError("HTTP 401: Invalid email or password.");
                } else {
                    showError("Server returned error code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                setLoading(false);
                showError("Network connection failed: " + t.getLocalizedMessage());
            }
        });
    }

    private void setLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!isLoading);
        etEmail.setEnabled(!isLoading);
        etPassword.setEnabled(!isLoading);
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void startDashboard() {
        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showServerConfigDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.server_config);

        final EditText input = new EditText(this);
        input.setPadding(32, 24, 32, 24);
        input.setText(SharedPrefManager.getInstance(this).getBaseUrl());
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newUrl = input.getText().toString().trim();
            if (!TextUtils.isEmpty(newUrl)) {
                SharedPrefManager.getInstance(LoginActivity.this).saveBaseUrl(newUrl);
                Toast.makeText(LoginActivity.this, "Server URL updated", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}