package com.emerson.example.warehouse_inventory_management_app.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class ApiResponse {
    @SerializedName("status")
    private Boolean status;

    @SerializedName("success")
    private Boolean success;

    @SerializedName("message")
    private String message;

    @SerializedName("error")
    private String error;

    @SerializedName("product")
    private Product product;

    @SerializedName("products")
    private List<Product> products;

    @SerializedName("categories")
    private List<Category> categories;

    public boolean isSuccess() {
        if (status != null) return status;
        if (success != null) return success;
        return (products != null || product != null || categories != null);
    }

    public String getMessage() {
        if (message != null && !message.isEmpty()) return message;
        if (error != null && !error.isEmpty()) return error;
        return isSuccess() ? "Operation completed successfully" : "Operation failed";
    }

    public Product getProduct() {
        return product;
    }

    public List<Product> getProducts() {
        return products;
    }

    public List<Category> getCategories() {
        return categories;
    }
}