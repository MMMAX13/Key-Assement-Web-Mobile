package com.emerson.example.warehouse_inventory_management_app.api;

import com.emerson.example.warehouse_inventory_management_app.models.ApiResponse;
import com.emerson.example.warehouse_inventory_management_app.models.Category;
import com.emerson.example.warehouse_inventory_management_app.models.LoginResponse;
import com.emerson.example.warehouse_inventory_management_app.models.Product;

import java.util.List;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {

    @FormUrlEncoded
    @POST("login.php")
    Call<LoginResponse> login(
            @Field("email") String email,
            @Field("password") String password
    );

    @GET("products.php")
    Call<List<Product>> getProducts(
            @Query("search") String search,
            @Query("category_id") Integer categoryId
    );

    @GET("products.php")
    Call<ApiResponse> getProductsWrapped(
            @Query("search") String search,
            @Query("category_id") Integer categoryId
    );

    @GET("categories.php")
    Call<List<Category>> getCategories();

    @GET("categories.php")
    Call<ApiResponse> getCategoriesWrapped();

    @Multipart
    @POST("products.php")
    Call<ApiResponse> addProduct(
            @Part("name") RequestBody name,
            @Part("sku") RequestBody sku,
            @Part("description") RequestBody description,
            @Part("category_id") RequestBody categoryId,
            @Part("unit_price") RequestBody unitPrice,
            @Part("quantity") RequestBody quantity,
            @Part("min_stock_threshold") RequestBody minStockThreshold,
            @Part MultipartBody.Part image
    );

    @Multipart
    @POST("products.php")
    Call<ApiResponse> addProductWithoutImage(
            @Part("name") RequestBody name,
            @Part("sku") RequestBody sku,
            @Part("description") RequestBody description,
            @Part("category_id") RequestBody categoryId,
            @Part("unit_price") RequestBody unitPrice,
            @Part("quantity") RequestBody quantity,
            @Part("min_stock_threshold") RequestBody minStockThreshold
    );

    @FormUrlEncoded
    @PUT("products.php")
    Call<ApiResponse> updateProduct(
            @Query("id") int id,
            @Field("name") String name,
            @Field("sku") String sku,
            @Field("description") String description,
            @Field("category_id") int categoryId,
            @Field("unit_price") double unitPrice,
            @Field("quantity") int quantity,
            @Field("min_stock_threshold") int minStockThreshold
    );

    @FormUrlEncoded
    @POST("products.php")
    Call<ApiResponse> updateProductPost(
            @Field("id") int id,
            @Field("action") String action,
            @Field("name") String name,
            @Field("sku") String sku,
            @Field("description") String description,
            @Field("category_id") int categoryId,
            @Field("unit_price") double unitPrice,
            @Field("quantity") int quantity,
            @Field("min_stock_threshold") int minStockThreshold
    );

    @DELETE("products.php")
    Call<ApiResponse> deleteProduct(
            @Query("id") int id
    );
}