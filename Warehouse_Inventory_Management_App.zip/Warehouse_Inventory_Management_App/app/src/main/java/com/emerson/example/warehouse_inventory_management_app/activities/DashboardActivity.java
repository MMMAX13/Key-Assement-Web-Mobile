package com.emerson.example.warehouse_inventory_management_app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.emerson.example.warehouse_inventory_management_app.R;
import com.emerson.example.warehouse_inventory_management_app.adapters.ProductAdapter;
import com.emerson.example.warehouse_inventory_management_app.api.ApiClient;
import com.emerson.example.warehouse_inventory_management_app.models.ApiResponse;
import com.emerson.example.warehouse_inventory_management_app.models.Product;
import com.emerson.example.warehouse_inventory_management_app.models.User;
import com.emerson.example.warehouse_inventory_management_app.utils.NotificationHelper;
import com.emerson.example.warehouse_inventory_management_app.utils.SharedPrefManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvWelcomeUser, tvUserRole, tvStatTotalProducts, tvStatLowStock, tvEmptyState;
    private EditText etSearch;
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerViewProducts;
    private ProgressBar progressBar;
    private FloatingActionButton fabAddProduct;
    private MaterialButton btnLogout;

    private ProductAdapter productAdapter;
    private List<Product> allProductsList = new ArrayList<>();
    private static final int PERMISSION_REQUEST_CODE_NOTIF = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        User currentUser = SharedPrefManager.getInstance(this).getUser();
        if (currentUser == null || !SharedPrefManager.getInstance(this).isLoggedIn()) {
            logoutUser();
            return;
        }

        initViews();
        setupUserHeader(currentUser);
        setupRecyclerView();
        setupSearchAndRefresh();
        checkNotificationPermission();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProducts();
    }

    private void initViews() {
        tvWelcomeUser = findViewById(R.id.tvWelcomeUser);
        tvUserRole = findViewById(R.id.tvUserRole);
        tvStatTotalProducts = findViewById(R.id.tvStatTotalProducts);
        tvStatLowStock = findViewById(R.id.tvStatLowStock);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        etSearch = findViewById(R.id.etSearch);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        recyclerViewProducts = findViewById(R.id.recyclerViewProducts);
        progressBar = findViewById(R.id.progressBar);
        fabAddProduct = findViewById(R.id.fabAddProduct);
        btnLogout = findViewById(R.id.btnLogout);

        btnLogout.setOnClickListener(v -> confirmLogout());
        fabAddProduct.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddProductActivity.class);
            startActivity(intent);
        });
    }

    private void setupUserHeader(User user) {
        String fullName = user.getFullName() != null ? user.getFullName() : "User";
        String role = user.getRole() != null ? user.getRole() : "Staff";

        tvWelcomeUser.setText(getString(R.string.welcome_user, fullName));
        tvUserRole.setText(getString(R.string.role_format, role));
    }

    private void setupRecyclerView() {
        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(this));
        productAdapter = new ProductAdapter(this, new ArrayList<>(), product -> {
            Intent intent = new Intent(DashboardActivity.this, ProductDetailActivity.class);
            intent.putExtra("product", product);
            startActivity(intent);
        });
        recyclerViewProducts.setAdapter(productAdapter);
    }

    private void setupSearchAndRefresh() {
        swipeRefreshLayout.setOnRefreshListener(this::loadProducts);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterProducts(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST_CODE_NOTIF);
            }
        }
    }

    private void loadProducts() {
        if (!swipeRefreshLayout.isRefreshing()) {
            progressBar.setVisibility(View.VISIBLE);
        }

        ApiClient.getApiService(this).getProducts(null, null).enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null) {
                    allProductsList = response.body();
                    updateProductData(allProductsList);
                } else {
                    // Try wrapped response format if flat list failed
                    loadProductsWrapped();
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                loadProductsWrapped();
            }
        });
    }

    private void loadProductsWrapped() {
        ApiClient.getApiService(this).getProductsWrapped(null, null).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null && response.body().getProducts() != null) {
                    allProductsList = response.body().getProducts();
                } else {
                    allProductsList = new ArrayList<>();
                }
                updateProductData(allProductsList);
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(DashboardActivity.this, "Failed to load products: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                updateProductData(new ArrayList<>());
            }
        });
    }

    private void updateProductData(List<Product> products) {
        int totalProducts = products.size();
        int lowStockCount = 0;

        for (Product p : products) {
            if (p.getQuantity() < p.getMinStockThreshold()) {
                lowStockCount++;
            }
        }

        tvStatTotalProducts.setText(String.valueOf(totalProducts));
        tvStatLowStock.setText(String.valueOf(lowStockCount));

        filterProducts(etSearch.getText() != null ? etSearch.getText().toString() : "");
    }

    private void filterProducts(String query) {
        List<Product> filteredList = new ArrayList<>();
        String cleanQuery = query.toLowerCase().trim();

        if (cleanQuery.isEmpty()) {
            filteredList.addAll(allProductsList);
        } else {
            for (Product p : allProductsList) {
                if (p.getName().toLowerCase().contains(cleanQuery) ||
                    p.getSku().toLowerCase().contains(cleanQuery) ||
                    p.getCategoryName().toLowerCase().contains(cleanQuery)) {
                    filteredList.add(p);
                }
            }
        }

        productAdapter.updateProducts(filteredList);
        tvEmptyState.setVisibility(filteredList.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
                .setTitle("Sign Out")
                .setMessage("Are you sure you want to sign out?")
                .setPositiveButton("Sign Out", (dialog, which) -> logoutUser())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void logoutUser() {
        SharedPrefManager.getInstance(this).clear();
        Intent intent = new Intent(DashboardActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}