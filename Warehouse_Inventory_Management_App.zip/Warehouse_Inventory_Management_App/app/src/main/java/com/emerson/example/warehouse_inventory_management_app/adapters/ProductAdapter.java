package com.emerson.example.warehouse_inventory_management_app.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.emerson.example.warehouse_inventory_management_app.R;
import com.emerson.example.warehouse_inventory_management_app.models.Product;
import com.emerson.example.warehouse_inventory_management_app.utils.SharedPrefManager;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    public interface OnProductClickListener {
        void onProductClick(Product product);
    }

    private final Context context;
    private List<Product> productList;
    private final OnProductClickListener listener;

    public ProductAdapter(Context context, List<Product> productList, OnProductClickListener listener) {
        this.context = context;
        this.productList = productList != null ? productList : new ArrayList<>();
        this.listener = listener;
    }

    public void updateProducts(List<Product> newProducts) {
        this.productList = newProducts != null ? newProducts : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProduct;
        TextView tvProductName, tvStockBadge, tvSku, tvCategory, tvPrice, tvQuantity;

        ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProduct = itemView.findViewById(R.id.imgProduct);
            tvProductName = itemView.findViewById(R.id.tvProductName);
            tvStockBadge = itemView.findViewById(R.id.tvStockBadge);
            tvSku = itemView.findViewById(R.id.tvSku);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
        }

        void bind(Product product) {
            tvProductName.setText(product.getName());
            tvSku.setText(context.getString(R.string.sku_format, product.getSku()));
            tvCategory.setText(context.getString(R.string.category_format, product.getCategoryName()));
            tvPrice.setText(String.format(Locale.US, "$%.2f", product.getUnitPrice()));
            tvQuantity.setText(String.format(Locale.US, "Qty: %d (Min: %d)", product.getQuantity(), product.getMinStockThreshold()));

            boolean isLowStock = product.getQuantity() < product.getMinStockThreshold();
            if (isLowStock) {
                tvStockBadge.setText(R.string.badge_low_stock);
                tvStockBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_low_stock));
                tvStockBadge.setTextColor(ContextCompat.getColor(context, R.color.stock_low_text));
            } else {
                tvStockBadge.setText(R.string.badge_ok_stock);
                tvStockBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_ok_stock));
                tvStockBadge.setTextColor(ContextCompat.getColor(context, R.color.stock_ok_text));
            }

            String imageUrl = product.getImage();
            if (!TextUtils.isEmpty(imageUrl)) {
                if (!imageUrl.startsWith("http://") && !imageUrl.startsWith("https://")) {
                    String baseUrl = SharedPrefManager.getInstance(context).getBaseUrl();
                    if (!baseUrl.endsWith("/")) baseUrl += "/";
                    imageUrl = baseUrl + imageUrl;
                }
                Picasso.get()
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_placeholder_product)
                        .error(R.drawable.ic_error_product)
                        .resize(200, 200)
                        .centerCrop()
                        .into(imgProduct);
            } else {
                imgProduct.setImageResource(R.drawable.ic_placeholder_product);
            }

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onProductClick(product);
                }
            });
        }
    }
}