package com.emerson.example.warehouse_inventory_management_app.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.emerson.example.warehouse_inventory_management_app.R;
import com.emerson.example.warehouse_inventory_management_app.api.ApiClient;
import com.emerson.example.warehouse_inventory_management_app.models.ApiResponse;
import com.emerson.example.warehouse_inventory_management_app.models.Category;
import com.emerson.example.warehouse_inventory_management_app.models.Product;
import com.emerson.example.warehouse_inventory_management_app.utils.NotificationHelper;
import com.emerson.example.warehouse_inventory_management_app.utils.SharedPrefManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    private ImageView imgProductDetail;
    private TextView tvStockBadge, tvQuickQuantity;
    private MaterialButton mBtnIncrease, mBtnDecrease, mBtnSave, mBtnDelete;
    private TextInputLayout tilName, tilSku, tilDescription, tilPrice, tilQuantity, tilMinStock;
    private TextInputEditText etName, etSku, etDescription, etPrice, etQuantity, etMinStock;
    private Spinner spinnerCategory;
    private ProgressBar progressBar;

    private Product currentProduct;
    private List<Category> categoryList = new ArrayList<>();
    private ArrayAdapter<Category> categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        if (getIntent() != null && getIntent().hasExtra("product")) {
            currentProduct = (Product) getIntent().getSerializableExtra("product");
        }

        if (currentProduct == null) {
            Toast.makeText(this, "Product details not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(currentProduct.getName());
        }

        initViews();
        populateFields();
        loadCategories();
    }

    private void initViews() {
        imgProductDetail = findViewById(R.id.imgProductDetail);
        tvStockBadge = findViewById(R.id.tvStockBadge);
        tvQuickQuantity = findViewById(R.id.tvQuickQuantity);

        mBtnIncrease = findViewById(R.id.btnIncreaseStock);
        mBtnDecrease = findViewById(R.id.btnDecreaseStock);
        mBtnSave = findViewById(R.id.btnSaveChanges);
        mBtnDelete = findViewById(R.id.btnDeleteProduct);

        tilName = findViewById(R.id.tilName);
        tilSku = findViewById(R.id.tilSku);
        tilDescription = findViewById(R.id.tilDescription);
        tilPrice = findViewById(R.id.tilPrice);
        tilQuantity = findViewById(R.id.tilQuantity);
        tilMinStock = findViewById(R.id.tilMinStock);

        etName = findViewById(R.id.etName);
        etSku = findViewById(R.id.etSku);
        etDescription = findViewById(R.id.etDescription);
        etPrice = findViewById(R.id.etPrice);
        etQuantity = findViewById(R.id.etQuantity);
        etMinStock = findViewById(R.id.etMinStock);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        progressBar = findViewById(R.id.progressBar);

        mBtnIncrease.setOnClickListener(v -> adjustQuantity(1));
        mBtnDecrease.setOnClickListener(v -> adjustQuantity(-1));
        mBtnSave.setOnClickListener(v -> saveProductChanges());
        mBtnDelete.setOnClickListener(v -> confirmDeleteProduct());

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateQuickQuantityDisplay();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        etMinStock.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateBadgeStatus();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void populateFields() {
        etName.setText(currentProduct.getName());
        etSku.setText(currentProduct.getSku());
        etDescription.setText(currentProduct.getDescription());
        etPrice.setText(String.format(Locale.US, "%.2f", currentProduct.getUnitPrice()));
        etQuantity.setText(String.valueOf(currentProduct.getQuantity()));
        etMinStock.setText(String.valueOf(currentProduct.getMinStockThreshold()));
        tvQuickQuantity.setText(String.valueOf(currentProduct.getQuantity()));

        updateBadgeStatus();

        String imageUrl = currentProduct.getImage();
        if (!TextUtils.isEmpty(imageUrl)) {
            if (!imageUrl.startsWith("http://") && !imageUrl.startsWith("https://")) {
                String baseUrl = SharedPrefManager.getInstance(this).getBaseUrl();
                if (!baseUrl.endsWith("/")) baseUrl += "/";
                imageUrl = baseUrl + imageUrl;
            }
            Picasso.get()
                    .load(imageUrl)
                    .placeholder(R.drawable.ic_placeholder_product)
                    .error(R.drawable.ic_error_product)
                    .resize(500, 300)
                    .centerCrop()
                    .into(imgProductDetail);
        } else {
            imgProductDetail.setImageResource(R.drawable.ic_placeholder_product);
        }
    }

    private void adjustQuantity(int delta) {
        int currentQty = parseInteger(etQuantity.getText() != null ? etQuantity.getText().toString() : "0");
        int newQty = Math.max(0, currentQty + delta);
        etQuantity.setText(String.valueOf(newQty));
        tvQuickQuantity.setText(String.valueOf(newQty));
        updateBadgeStatus();
    }

    private void updateQuickQuantityDisplay() {
        int qty = parseInteger(etQuantity.getText() != null ? etQuantity.getText().toString() : "0");
        tvQuickQuantity.setText(String.valueOf(qty));
        updateBadgeStatus();
    }

    private void updateBadgeStatus() {
        int qty = parseInteger(etQuantity.getText() != null ? etQuantity.getText().toString() : "0");
        int minStock = parseInteger(etMinStock.getText() != null ? etMinStock.getText().toString() : "0");

        if (qty < minStock) {
            tvStockBadge.setText(R.string.badge_low_stock);
            tvStockBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_low_stock));
            tvStockBadge.setTextColor(ContextCompat.getColor(this, R.color.stock_low_text));
        } else {
            tvStockBadge.setText(R.string.badge_ok_stock);
            tvStockBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_ok_stock));
            tvStockBadge.setTextColor(ContextCompat.getColor(this, R.color.stock_ok_text));
        }
    }

    private void loadCategories() {
        ApiClient.getApiService(this).getCategories().enqueue(new Callback<List<Category>>() {
            @Override
            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    categoryList = response.body();
                } else {
                    populateFallbackCategories();
                }
                setupCategorySpinner();
            }

            @Override
            public void onFailure(Call<List<Category>> call, Throwable t) {
                populateFallbackCategories();
                setupCategorySpinner();
            }
        });
    }

    private void populateFallbackCategories() {
        categoryList = new ArrayList<>();
        categoryList.add(new Category(1, "Electronics & Hardware"));
        categoryList.add(new Category(2, "Tools & Equipment"));
        categoryList.add(new Category(3, "Office & Stationeries"));
        categoryList.add(new Category(4, "Raw Materials"));
        categoryList.add(new Category(5, "Packaging & Shipping"));
    }

    private void setupCategorySpinner() {
        categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categoryList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);

        // Select matching category item
        for (int i = 0; i < categoryList.size(); i++) {
            if (categoryList.get(i).getId() == currentProduct.getCategoryId() ||
                    categoryList.get(i).getName().equalsIgnoreCase(currentProduct.getCategoryName())) {
                spinnerCategory.setSelection(i);
                break;
            }
        }
    }

    private void saveProductChanges() {
        clearErrors();

        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String sku = etSku.getText() != null ? etSku.getText().toString().trim() : "";
        String description = etDescription.getText() != null ? etDescription.getText().toString().trim() : "";
        String priceStr = etPrice.getText() != null ? etPrice.getText().toString().trim() : "";
        String qtyStr = etQuantity.getText() != null ? etQuantity.getText().toString().trim() : "";
        String minStockStr = etMinStock.getText() != null ? etMinStock.getText().toString().trim() : "";

        if (TextUtils.isEmpty(name)) {
            tilName.setError("Product name is required");
            return;
        }
        if (TextUtils.isEmpty(sku)) {
            tilSku.setError("SKU is required");
            return;
        }
        if (TextUtils.isEmpty(priceStr)) {
            tilPrice.setError("Price is required");
            return;
        }
        if (TextUtils.isEmpty(qtyStr)) {
            tilQuantity.setError("Quantity is required");
            return;
        }
        if (TextUtils.isEmpty(minStockStr)) {
            tilMinStock.setError("Minimum stock threshold is required");
            return;
        }

        double price = parseDouble(priceStr);
        int newQuantity = parseInteger(qtyStr);
        int newMinStock = parseInteger(minStockStr);

        int categoryId = currentProduct.getCategoryId();
        String categoryName = currentProduct.getCategoryName();
        if (spinnerCategory.getSelectedItem() instanceof Category) {
            Category selectedCategory = (Category) spinnerCategory.getSelectedItem();
            categoryId = selectedCategory.getId();
            categoryName = selectedCategory.getName();
        }

        final boolean wasLowStock = currentProduct.getQuantity() < currentProduct.getMinStockThreshold();
        final boolean isNowLowStock = newQuantity < newMinStock;

        setLoading(true);

        final int finalCategoryId = categoryId;
        final String finalCategoryName = categoryName;

        ApiClient.getApiService(this).updateProduct(
                currentProduct.getId(),
                name,
                sku,
                description,
                categoryId,
                price,
                newQuantity,
                newMinStock
        ).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                setLoading(false);
                if (response.isSuccessful() && (response.body() == null || response.body().isSuccess())) {
                    currentProduct.setName(name);
                    currentProduct.setSku(sku);
                    currentProduct.setDescription(description);
                    currentProduct.setUnitPrice(price);
                    currentProduct.setQuantity(newQuantity);
                    currentProduct.setMinStockThreshold(newMinStock);
                    currentProduct.setCategoryId(finalCategoryId);
                    currentProduct.setCategoryName(finalCategoryName);

                    // Low-Stock Hardware Alert check
                    if (!wasLowStock && isNowLowStock) {
                        NotificationHelper.triggerLowStockAlert(ProductDetailActivity.this, currentProduct);
                    }

                    Toast.makeText(ProductDetailActivity.this, "Product updated successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    String msg = response.body() != null ? response.body().getMessage() : "Update failed";
                    Toast.makeText(ProductDetailActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                setLoading(false);
                // Fallback attempt via POST endpoint if server does not accept PUT method
                updateProductPostFallback(name, sku, description, finalCategoryId, price, newQuantity, newMinStock, wasLowStock, isNowLowStock);
            }
        });
    }

    private void updateProductPostFallback(String name, String sku, String description, int categoryId,
                                           double price, int newQuantity, int newMinStock,
                                           boolean wasLowStock, boolean isNowLowStock) {
        ApiClient.getApiService(this).updateProductPost(
                currentProduct.getId(),
                "update",
                name,
                sku,
                description,
                categoryId,
                price,
                newQuantity,
                newMinStock
        ).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                setLoading(false);
                if (response.isSuccessful() && (response.body() == null || response.body().isSuccess())) {
                    currentProduct.setQuantity(newQuantity);
                    currentProduct.setMinStockThreshold(newMinStock);
                    if (!wasLowStock && isNowLowStock) {
                        NotificationHelper.triggerLowStockAlert(ProductDetailActivity.this, currentProduct);
                    }
                    Toast.makeText(ProductDetailActivity.this, "Product updated successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(ProductDetailActivity.this, "Failed to update product on server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                setLoading(false);
                Toast.makeText(ProductDetailActivity.this, "Network error: " + t.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void confirmDeleteProduct() {
        String msg = getString(R.string.delete_confirm_msg, currentProduct.getName());
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(msg)
                .setPositiveButton("Delete", (dialog, which) -> executeDeleteProduct())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void executeDeleteProduct() {
        setLoading(true);
        ApiClient.getApiService(this).deleteProduct(currentProduct.getId()).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                setLoading(false);
                if (response.isSuccessful() && (response.body() == null || response.body().isSuccess())) {
                    Toast.makeText(ProductDetailActivity.this, "Product deleted", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    String msg = response.body() != null ? response.body().getMessage() : "Delete failed";
                    Toast.makeText(ProductDetailActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                setLoading(false);
                Toast.makeText(ProductDetailActivity.this, "Network error: " + t.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private int parseInteger(String str) {
        try {
            return Integer.parseInt(str.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private double parseDouble(String str) {
        try {
            return Double.parseDouble(str.trim());
        } catch (Exception e) {
            return 0.0;
        }
    }

    private void clearErrors() {
        tilName.setError(null);
        tilSku.setError(null);
        tilDescription.setError(null);
        tilPrice.setError(null);
        tilQuantity.setError(null);
        tilMinStock.setError(null);
    }

    private void setLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        mBtnSave.setEnabled(!isLoading);
        mBtnDelete.setEnabled(!isLoading);
        mBtnIncrease.setEnabled(!isLoading);
        mBtnDecrease.setEnabled(!isLoading);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}