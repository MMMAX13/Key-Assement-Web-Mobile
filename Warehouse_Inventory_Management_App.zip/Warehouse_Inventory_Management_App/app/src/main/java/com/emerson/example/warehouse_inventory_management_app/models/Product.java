package com.emerson.example.warehouse_inventory_management_app.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Product implements Serializable {
    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;

    @SerializedName("sku")
    private String sku;

    @SerializedName("description")
    private String description;

    @SerializedName("category_id")
    private int categoryId;

    @SerializedName("category_name")
    private String categoryName;

    @SerializedName("unit_price")
    private Double unitPrice;

    @SerializedName("price")
    private Double price;

    @SerializedName("quantity")
    private int quantity;

    @SerializedName("min_stock_threshold")
    private int minStockThreshold;

    @SerializedName("image")
    private String image;

    @SerializedName("image_url")
    private String imageUrl;

    public Product() {
    }

    public Product(int id, String name, String sku, String description, int categoryId,
                   String categoryName, double unitPrice, int quantity, int minStockThreshold, String image) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.description = description;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.minStockThreshold = minStockThreshold;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name != null ? name : "";
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSku() {
        return sku != null ? sku : "";
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getDescription() {
        return description != null ? description : "";
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName != null ? categoryName : "General";
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public double getUnitPrice() {
        if (unitPrice != null) return unitPrice;
        if (price != null) return price;
        return 0.0;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getMinStockThreshold() {
        return minStockThreshold;
    }

    public void setMinStockThreshold(int minStockThreshold) {
        this.minStockThreshold = minStockThreshold;
    }

    public String getImage() {
        if (image != null && !image.trim().isEmpty()) return image;
        if (imageUrl != null && !imageUrl.trim().isEmpty()) return imageUrl;
        return "";
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isLowStock() {
        return quantity < minStockThreshold;
    }
}