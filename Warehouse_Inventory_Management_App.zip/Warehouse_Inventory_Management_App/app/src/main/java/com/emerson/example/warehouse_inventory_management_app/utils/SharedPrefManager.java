package com.emerson.example.warehouse_inventory_management_app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.emerson.example.warehouse_inventory_management_app.api.ApiClient;
import com.emerson.example.warehouse_inventory_management_app.models.User;

public class SharedPrefManager {
    private static final String SHARED_PREF_NAME = "warehouse_inventory_pref";
    private static final String KEY_USER_ID = "key_user_id";
    private static final String KEY_FULL_NAME = "key_full_name";
    private static final String KEY_EMAIL = "key_email";
    private static final String KEY_ROLE = "key_role";
    private static final String KEY_IS_LOGGED_IN = "key_is_logged_in";
    private static final String KEY_BASE_URL = "key_base_url";

    private static SharedPrefManager mInstance;
    private final Context mContext;

    private SharedPrefManager(Context context) {
        mContext = context.getApplicationContext();
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    public void saveUser(User user) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_USER_ID, user.getId());
        editor.putString(KEY_FULL_NAME, user.getFullName());
        editor.putString(KEY_EMAIL, user.getEmail());
        editor.putString(KEY_ROLE, user.getRole());
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.apply();
    }

    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public User getUser() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new User(
                sharedPreferences.getInt(KEY_USER_ID, -1),
                sharedPreferences.getString(KEY_FULL_NAME, null),
                sharedPreferences.getString(KEY_EMAIL, null),
                sharedPreferences.getString(KEY_ROLE, null)
        );
    }

    public void saveBaseUrl(String url) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_BASE_URL, url);
        editor.apply();
        ApiClient.resetClient();
    }

    public String getBaseUrl() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_BASE_URL, ApiClient.DEFAULT_BASE_URL);
    }

    public void clear() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String currentBaseUrl = getBaseUrl();
        editor.clear();
        editor.putString(KEY_BASE_URL, currentBaseUrl);
        editor.apply();
    }
}