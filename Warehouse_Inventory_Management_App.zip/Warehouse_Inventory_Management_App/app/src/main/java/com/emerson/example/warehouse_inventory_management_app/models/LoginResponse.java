package com.emerson.example.warehouse_inventory_management_app.models;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    @SerializedName("status")
    private Boolean status;

    @SerializedName("success")
    private Boolean success;

    @SerializedName("message")
    private String message;

    @SerializedName("user")
    private User user;

    // Direct fields in case backend returns flat json
    @SerializedName("id")
    private Integer id;

    @SerializedName("full_name")
    private String fullName;

    @SerializedName("email")
    private String email;

    @SerializedName("role")
    private String role;

    public boolean isSuccess() {
        if (status != null) return status;
        if (success != null) return success;
        return (user != null || id != null);
    }

    public String getMessage() {
        return message != null ? message : "Login response received";
    }

    public User getUser() {
        if (user != null) {
            return user;
        }
        if (id != null || fullName != null || email != null) {
            return new User(
                id != null ? id : 0,
                fullName != null ? fullName : "User",
                email != null ? email : "",
                role != null ? role : "Staff"
            );
        }
        return null;
    }
}