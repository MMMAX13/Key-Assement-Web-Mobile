package com.emerson.example.warehouse_inventory_management_app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.emerson.example.warehouse_inventory_management_app.R;
import com.emerson.example.warehouse_inventory_management_app.api.ApiClient;
import com.emerson.example.warehouse_inventory_management_app.models.ApiResponse;
import com.emerson.example.warehouse_inventory_management_app.models.Category;
import com.emerson.example.warehouse_inventory_management_app.utils.FileUtils;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddProductActivity extends AppCompatActivity {

    private ImageView imgProductPreview;
    private MaterialButton btnCamera, btnGallery, btnSubmit;
    private TextInputLayout tilName, tilSku, tilDescription, tilPrice, tilQuantity, tilMinStock;
    private TextInputEditText etName, etSku, etDescription, etPrice, etQuantity, etMinStock;
    private Spinner spinnerCategory;
    private ProgressBar progressBar;

    private List<Category> categoryList = new ArrayList<>();
    private ArrayAdapter<Category> categoryAdapter;

    private Uri selectedImageUri;
    private File photoFile;

    private ActivityResultLauncher<Intent> cameraLauncher;
    private ActivityResultLauncher<String> galleryLauncher;
    private ActivityResultLauncher<String> cameraPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.add_product_title);
        }

        initViews();
        setupLaunchers();
        loadCategories();
    }

    private void initViews() {
        imgProductPreview = findViewById(R.id.imgProductPreview);
        btnCamera = findViewById(R.id.btnCamera);
        btnGallery = findViewById(R.id.btnGallery);
        btnSubmit = findViewById(R.id.btnSubmit);

        tilName = findViewById(R.id.tilName);
        tilSku = findViewById(R.id.tilSku);
        tilDescription = findViewById(R.id.tilDescription);
        tilPrice = findViewById(R.id.tilPrice);
        tilQuantity = findViewById(R.id.tilQuantity);
        tilMinStock = findViewById(R.id.tilMinStock);

        etName = findViewById(R.id.etName);
        etSku = findViewById(R.id.etSku);
        etDescription = findViewById(R.id.etDescription);
        etPrice = findViewById(R.id.etPrice);
        etQuantity = findViewById(R.id.etQuantity);
        etMinStock = findViewById(R.id.etMinStock);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        progressBar = findViewById(R.id.progressBar);

        btnCamera.setOnClickListener(v -> checkCameraPermissionAndLaunch());
        btnGallery.setOnClickListener(v -> galleryLauncher.launch("image/*"));
        btnSubmit.setOnClickListener(v -> submitProduct());
    }

    private void setupLaunchers() {
        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && photoFile != null) {
                        selectedImageUri = Uri.fromFile(photoFile);
                        imgProductPreview.setImageURI(selectedImageUri);
                    }
                }
        );

        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri;
                        imgProductPreview.setImageURI(selectedImageUri);
                    }
                }
        );

        cameraPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        launchCameraIntent();
                    } else {
                        Toast.makeText(this, "Camera permission required to take photos", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    private void checkCameraPermissionAndLaunch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchCameraIntent();
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void launchCameraIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoFile = createImageFile();
                if (photoFile != null) {
                    Uri photoURI = FileProvider.getUriForFile(
                            this,
                            getApplicationContext().getPackageName() + ".fileprovider",
                            photoFile
                    );
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    cameraLauncher.launch(takePictureIntent);
                }
            } catch (IOException ex) {
                Toast.makeText(this, "Error creating image file", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    private void loadCategories() {
        ApiClient.getApiService(this).getCategories().enqueue(new Callback<List<Category>>() {
            @Override
            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    categoryList = response.body();
                } else {
                    populateFallbackCategories();
                }
                setupCategorySpinner();
            }

            @Override
            public void onFailure(Call<List<Category>> call, Throwable t) {
                populateFallbackCategories();
                setupCategorySpinner();
            }
        });
    }

    private void populateFallbackCategories() {
        categoryList = new ArrayList<>();
        categoryList.add(new Category(1, "Electronics & Hardware"));
        categoryList.add(new Category(2, "Tools & Equipment"));
        categoryList.add(new Category(3, "Office & Stationeries"));
        categoryList.add(new Category(4, "Raw Materials"));
        categoryList.add(new Category(5, "Packaging & Shipping"));
    }

    private void setupCategorySpinner() {
        categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categoryList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);
    }

    private void submitProduct() {
        clearErrors();

        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String sku = etSku.getText() != null ? etSku.getText().toString().trim() : "";
        String description = etDescription.getText() != null ? etDescription.getText().toString().trim() : "";
        String priceStr = etPrice.getText() != null ? etPrice.getText().toString().trim() : "";
        String qtyStr = etQuantity.getText() != null ? etQuantity.getText().toString().trim() : "";
        String minStockStr = etMinStock.getText() != null ? etMinStock.getText().toString().trim() : "";

        boolean cancel = false;

        if (TextUtils.isEmpty(name)) {
            tilName.setError("Product name is required");
            cancel = true;
        }

        if (TextUtils.isEmpty(sku)) {
            tilSku.setError("SKU code is required");
            cancel = true;
        }

        if (TextUtils.isEmpty(priceStr)) {
            tilPrice.setError("Unit price is required");
            cancel = true;
        }

        if (TextUtils.isEmpty(qtyStr)) {
            tilQuantity.setError("Quantity is required");
            cancel = true;
        }

        if (TextUtils.isEmpty(minStockStr)) {
            tilMinStock.setError("Minimum stock threshold is required");
            cancel = true;
        }

        if (cancel) return;

        int categoryId = 1;
        if (spinnerCategory.getSelectedItem() instanceof Category) {
            categoryId = ((Category) spinnerCategory.getSelectedItem()).getId();
        }

        setLoading(true);

        RequestBody reqName = createPartFromString(name);
        RequestBody reqSku = createPartFromString(sku);
        RequestBody reqDesc = createPartFromString(description);
        RequestBody reqCatId = createPartFromString(String.valueOf(categoryId));
        RequestBody reqPrice = createPartFromString(priceStr);
        RequestBody reqQty = createPartFromString(qtyStr);
        RequestBody reqMinStock = createPartFromString(minStockStr);

        MultipartBody.Part bodyImage = null;
        if (selectedImageUri != null) {
            File file = FileUtils.getFileFromUri(this, selectedImageUri);
            if (file != null) {
                RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
                bodyImage = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
            }
        }

        Call<ApiResponse> call;
        if (bodyImage != null) {
            call = ApiClient.getApiService(this).addProduct(
                    reqName, reqSku, reqDesc, reqCatId, reqPrice, reqQty, reqMinStock, bodyImage
            );
        } else {
            call = ApiClient.getApiService(this).addProductWithoutImage(
                    reqName, reqSku, reqDesc, reqCatId, reqPrice, reqQty, reqMinStock
            );
        }

        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    Toast.makeText(AddProductActivity.this, "Product registered successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    String msg = (response.body() != null) ? response.body().getMessage() : "Failed to save product";
                    Toast.makeText(AddProductActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                setLoading(false);
                Toast.makeText(AddProductActivity.this, "Network error: " + t.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private RequestBody createPartFromString(String value) {
        return RequestBody.create(MediaType.parse("multipart/form-data"), value != null ? value : "");
    }

    private void clearErrors() {
        tilName.setError(null);
        tilSku.setError(null);
        tilDescription.setError(null);
        tilPrice.setError(null);
        tilQuantity.setError(null);
        tilMinStock.setError(null);
    }

    private void setLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        btnSubmit.setEnabled(!isLoading);
        btnCamera.setEnabled(!isLoading);
        btnGallery.setEnabled(!isLoading);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}