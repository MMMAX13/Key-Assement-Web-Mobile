package com.emerson.example.warehouse_inventory_management_app;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.emerson.example.warehouse_inventory_management_app.activities.DashboardActivity;
import com.emerson.example.warehouse_inventory_management_app.activities.LoginActivity;
import com.emerson.example.warehouse_inventory_management_app.utils.SharedPrefManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (SharedPrefManager.getInstance(this).isLoggedIn()) {
            startActivity(new Intent(this, DashboardActivity.class));
        } else {
            startActivity(new Intent(this, LoginActivity.class));
        }
        finish();
    }
}